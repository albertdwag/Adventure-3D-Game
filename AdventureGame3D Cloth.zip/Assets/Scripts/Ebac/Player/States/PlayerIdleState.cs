using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Ebac.StateMachine;

public class PlayerIdleState : StateBase
{
    public override void OnStateEnter(params object[] objs)
    {

    }

    public override void OnStateStay()
    {

    }

    public override void OnStateExit()
    {

    }
}
